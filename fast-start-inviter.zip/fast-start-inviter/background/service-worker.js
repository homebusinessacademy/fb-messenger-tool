// Fast Start Inviter — Service Worker (Chrome MV3)
// All logic self-contained; no ES module imports needed

// ─── Message Variations (inlined) ──────────────────────────────────────────

const MESSAGE_VARIATIONS = [
  "Hey {{first_name}}, hope you're having a {great|wonderful|fantastic} day! Quick question. I recently {ran across|came across|found} a {project|business project|business model} that looks like it could be pretty {lucrative|profitable|great}. Would you be open to {taking a peek|checking it out|taking a look}? No worries {if not|if no}, just let me know.",

  "Hey {{first_name}}, hope you're doing well. This might not be for you, but you came to mind when I saw it, so {wanted to touch base|thought I'd reach out} just in case. It's an online {marketing|business} project, different from anything I've seen before, and looks like it could be a pretty {good money maker|lucrative income stream|great income generator}. Does that sound like something you'd be open to {taking a look at|checking out}?",

  "Hi {{first_name}}, hope {all is well in your world|everything's going great|life is treating you well}. \uD83D\uDE42 I just {found|came across} something that made me think of you. It's an online business that's pretty {unique|different|one of a kind}. Honestly, I've never seen anything quite like it. Anyway, it looks like it could have some pretty {good|solid|great} potential so I wanted to reach out to see if you'd be open to taking a look?",

  "Hey {{first_name}}, hope you're having an {awesome|amazing|great} day! I just {saw|came across|found} a very unique {business project|project|business model} that made me think of you. {Who knows, maybe I'm crazy|Maybe it's a long shot}, but wanted to reach out just in case. Are you open to {checking out|exploring|looking at} any ways to {generate income|make money|create income} outside of what you're currently doing?",

  "Hey {{first_name}}, hope {all is good|everything's great|you're doing well}! {Random question|Quick question}. I just saw something that I'm pretty {excited|pumped} about. It's a business {project|model} that's {quite|pretty} unique. Wondering if you might be open to taking a look? No worries if not, just let me know. {Love to hear what you've been up to these days too|Would love to catch up too}!"
];

// ─── Spintax Parser (inlined) ───────────────────────────────────────────────

function spinText(template) {
  const pattern = /\{([^{}]+\|[^{}]+)\}/g;
  return template.replace(pattern, (match, options) => {
    const choices = options.split('|');
    return choices[Math.floor(Math.random() * choices.length)].trim();
  });
}

function applyMessage(variationIndex, firstName) {
  const template = MESSAGE_VARIATIONS[variationIndex] || MESSAGE_VARIATIONS[0];
  const spun = spinText(template);
  return spun.replace(/\{\{first_name\}\}/g, firstName);
}

function getRandomVariationIndex(lastIndex = null) {
  const indices = [0, 1, 2, 3, 4];
  if (lastIndex !== null) {
    const filtered = indices.filter(i => i !== lastIndex);
    return filtered[Math.floor(Math.random() * filtered.length)];
  }
  return Math.floor(Math.random() * indices.length);
}

// ─── Constants ───────────────────────────────────────────────────────────────

const MAX_DAILY = 10;
const WINDOW_START_HOUR = 9;   // 9am
const WINDOW_END_HOUR = 20;    // 8pm

// ⚠️ TEST MODE — set TEST_MODE = true for testing (1-2 min gaps, no time window)
const TEST_MODE = false; // LIVE MODE: 30-60 min gaps, 9am-8pm window
const MIN_GAP_MIN = TEST_MODE ? 1   : 30;
const MAX_GAP_MIN = TEST_MODE ? 2   : 60;
const DEFER_MIN   = TEST_MODE ? 1   : 15;

const ALARM_NAME = 'send-next-message';

// ─── HBA API Configuration ───────────────────────────────────────────────────

const HBA_API_BASE = 'https://thehba.app/api';

// Generate or retrieve device ID (persisted UUID)
async function getDeviceId() {
  const data = await getStorage(['deviceId']);
  if (data.deviceId) return data.deviceId;
  
  // Generate new UUID
  const deviceId = crypto.randomUUID();
  await setStorage({ deviceId });
  return deviceId;
}

// Get stored auth token
async function getAuthToken() {
  const data = await getStorage(['authToken']);
  return data.authToken || null;
}

// Authenticate with device binding (returns { success, token?, error?, message? })
async function authenticateDevice(email) {
  try {
    const deviceId = await getDeviceId();
    const res = await fetch(`${HBA_API_BASE}/fast-start/auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, deviceId })
    });
    const data = await res.json();
    
    if (data.success && data.token) {
      // Store the token
      await setStorage({ authToken: data.token, memberEmail: email });
    }
    
    return data;
  } catch (err) {
    console.error('[FSI] authenticateDevice error:', err);
    return { success: false, error: 'network_error', message: 'Unable to connect. Please try again.' };
  }
}

// Log an invite to global registry (protected by user token)
async function logInvite(facebookId) {
  try {
    const token = await getAuthToken();
    if (!token) return false;
    
    const res = await fetch(`${HBA_API_BASE}/fast-start/invites`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ facebookId })
    });
    const data = await res.json();
    return data.success === true;
  } catch (err) {
    console.error('[FSI] logInvite error:', err);
    return false;
  }
}

// Bulk check which friends have been invited (protected by user token)
async function bulkCheckInvites(facebookIds) {
  try {
    const token = await getAuthToken();
    if (!token) return {};
    
    const res = await fetch(`${HBA_API_BASE}/fast-start/invites/check`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ facebookIds })
    });
    const data = await res.json();
    return data; // { "john.smith.123": "2025-12-21", ... }
  } catch (err) {
    console.error('[FSI] bulkCheckInvites error:', err);
    return {};
  }
}

// ─── Storage Helpers ─────────────────────────────────────────────────────────

async function getStorage(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

async function setStorage(data) {
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

// ─── Time Helpers ─────────────────────────────────────────────────────────────

function isInWindow(now = new Date()) {
  if (TEST_MODE) return true; // No time restriction in test mode
  const h = now.getHours();
  return h >= WINDOW_START_HOUR && h < WINDOW_END_HOUR;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function minutesUntilWindowOpen() {
  const now = new Date();
  const h = now.getHours();
  if (h < WINDOW_START_HOUR) {
    return (WINDOW_START_HOUR - h) * 60 - now.getMinutes();
  }
  // After window: schedule for 9am tomorrow
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(WINDOW_START_HOUR, 0, 0, 0);
  return Math.ceil((tomorrow - now) / 60000);
}

function randomGapMinutes() {
  return MIN_GAP_MIN + Math.floor(Math.random() * (MAX_GAP_MIN - MIN_GAP_MIN + 1));
}

// ─── Alarm Scheduling ────────────────────────────────────────────────────────

function scheduleAlarm(delayMinutes) {
  chrome.alarms.clear(ALARM_NAME, () => {
    chrome.alarms.create(ALARM_NAME, { delayInMinutes: delayMinutes });
    console.log(`[FSI] Next alarm in ${delayMinutes.toFixed(1)} min`);
  });
}

// ─── Campaign Logic ──────────────────────────────────────────────────────────

async function getNextPendingFriend(campaign) {
  const { selectedFriendIds, sendRecords } = campaign;
  for (const friendId of selectedFriendIds) {
    const rec = sendRecords[friendId];
    // Only return friends that haven't been processed yet
    if (!rec || rec.status === 'pending') {
      return friendId;
    }
    // Skip friends that are sent, failed, or skipped
  }
  return null;
}

// Wait for a tab to finish loading
function waitForTabLoad(tabId, timeoutMs = 20000) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function sendToFriend(friendId, campaign) {
  const { friends = [] } = await getStorage(['friends']);
  const friend = friends.find(f => f.id === friendId);
  if (!friend) {
    console.warn(`[FSI] Friend not found: ${friendId}`);
    return false;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // JUST-IN-TIME CHECK: Skip if already invited by another member (within 1 year)
  // This prevents race conditions where two members try to invite the same person
  // ═══════════════════════════════════════════════════════════════════════════
  const checkResult = await bulkCheckInvites([friendId]);
  if (checkResult[friendId]) {
    console.log(`[FSI] Skipping ${friend.name} — already invited on ${checkResult[friendId]}`);
    campaign.sendRecords[friendId] = {
      status: 'skipped',
      messageVariation: null,
      scheduledAt: new Date().toISOString(),
      sentAt: null,
      error: 'Already invited by another HBA member'
    };
    await setStorage({ campaign });
    return false; // Skip this friend, move to next
  }
  // ═══════════════════════════════════════════════════════════════════════════

  const lastVariation = campaign.lastVariationIndex ?? null;
  const variationIndex = getRandomVariationIndex(lastVariation);
  const message = applyMessage(variationIndex, friend.firstName || friend.name.split(' ')[0]);

  // Open facebook.com/messages — stays in Chrome (messenger.com triggers desktop app)
  const url = `https://www.facebook.com/messages/t/${friendId}`;
  console.log(`[FSI] Opening tab: ${url}`);
  const tab = await new Promise(resolve => chrome.tabs.create({ url, active: true }, resolve));

  // Wait for page to fully load, then give Messenger UI time to mount
  await waitForTabLoad(tab.id, 20000);
  await sleep(4000);
  console.log(`[FSI] Tab loaded, looking for input...`);

  try {
    const exec = (func, args) => chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args });

    // Step 0: Handle encryption upgrade prompt ("Continue" button)
    const clickedContinue = await exec(() => {
      // Look for Continue button in encryption upgrade dialog
      const buttons = Array.from(document.querySelectorAll('[role="button"]'));
      const continueBtn = buttons.find(b => b.textContent?.trim() === 'Continue');
      if (continueBtn) {
        continueBtn.click();
        return true;
      }
      return false;
    });
    if (clickedContinue[0]?.result) {
      console.log('[FSI] Clicked encryption Continue button, waiting for UI...');
      await sleep(2000);
    }

    // Step 1: Poll for input (up to 12s)
    let inputFound = false;
    for (let i = 0; i < 24; i++) {
      const r = await exec(() => !!document.querySelector('[role="textbox"][contenteditable="true"]'));
      if (r[0]?.result) { inputFound = true; break; }
      await sleep(500);
    }
    if (!inputFound) throw new Error('Input not found after 12s — Messenger UI may not have loaded');
    console.log('[FSI] Input found, pasting message...');

    // Note: Removed defer check — it was broken (we open tab as active, so hasFocus always true)
    // User chose to start campaign; we'll send. If they're chatting, they can pause.

    // Step 2: Insert message via execCommand (proven working)
    console.log('[FSI] Inserting message via execCommand...');
    
    await exec((msg) => {
      const input = document.querySelector('[role="textbox"][contenteditable="true"]');
      if (!input) return;
      
      input.focus();
      
      // Clear any existing content first
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      
      // Insert full message at once
      document.execCommand('insertText', false, msg);
    }, [message]);
    
    // Brief pause to let React/Lexical sync
    await sleep(300);
    
    // Verify text was inserted
    const verifyInsert = await exec(() => {
      const input = document.querySelector('[role="textbox"][contenteditable="true"]');
      const actual = (input?.textContent || '').trim();
      return { ok: actual.length > 0, actual: actual.substring(0, 50) };
    });
    
    const insertVerify = verifyInsert[0]?.result;
    if (!insertVerify?.ok) throw new Error(`Text insert failed: input is empty`);
    console.log(`[FSI] Message inserted: "${insertVerify.actual}...", pressing Enter...`);

    await sleep(700);

    // Step 3: Press Enter to send (multiple strategies)
    const sendResult = await exec(() => {
      const input = document.querySelector('[role="textbox"][contenteditable="true"]');
      if (!input) return { sent: false, method: 'none', error: 'input not found' };
      
      // Strategy 1: Click send button if it exists
      const sendBtn = document.querySelector('[aria-label="Press enter to send"]') 
        || document.querySelector('[aria-label="Send"]')
        || document.querySelector('[data-testid="send-button"]');
      if (sendBtn) {
        sendBtn.click();
        return { sent: true, method: 'sendButton' };
      }

      // Strategy 2: Full keyboard event sequence on input
      const enterOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      input.dispatchEvent(new KeyboardEvent('keydown', enterOpts));
      input.dispatchEvent(new KeyboardEvent('keypress', enterOpts));
      input.dispatchEvent(new KeyboardEvent('keyup', enterOpts));
      
      return { sent: true, method: 'keyboardEvents' };
    });
    console.log(`[FSI] Send attempted via ${sendResult[0]?.result?.method}`);

    await sleep(2500);

    // Step 4: Verify sent - check for our message in conversation OR input cleared
    const verification = await exec((msgSnippet) => {
      const input = document.querySelector('[role="textbox"][contenteditable="true"]');
      const inputCleared = !input || (input.textContent || '').trim() === '';
      
      // Look for sent message bubbles (they appear on the right side with specific attributes)
      const messages = document.querySelectorAll('[data-scope="messages_table"] [dir="auto"]');
      const lastMessages = Array.from(messages).slice(-5);
      const foundOurMessage = lastMessages.some(m => (m.textContent || '').includes(msgSnippet));
      
      return { inputCleared, foundOurMessage, lastMsgCount: messages.length };
    }, [message.substring(0, 30)]); // Check first 30 chars of our message
    
    const v = verification[0]?.result;
    const success = v?.inputCleared; // For now, trust input cleared (we'll refine later)
    const result = { success, error: success ? null : 'Message may not have sent' };

    if (result?.success) {
      const now = new Date().toISOString();
      campaign.sendRecords[friendId] = {
        status: 'sent',
        messageVariation: variationIndex,
        scheduledAt: campaign.sendRecords[friendId]?.scheduledAt || now,
        sentAt: now,
        error: null
      };
      campaign.sentToday = (campaign.sentToday || 0) + 1;
      campaign.lastVariationIndex = variationIndex;
      
      // Save immediately so we don't lose the record
      await setStorage({ campaign });
      
      // DEBUG: Verify the save worked
      const verify = await getStorage(['campaign']);
      const savedSent = Object.values(verify.campaign?.sendRecords || {}).filter(r => r.status === 'sent').length;
      console.log(`[FSI] DEBUG: Saved campaign, sendRecords has ${savedSent} sent (friendId: ${friendId})`);
      
      // Update badge with today's progress
      const totalSent = Object.values(campaign.sendRecords).filter(r => r.status === 'sent').length;
      chrome.action.setBadgeText({ text: `${totalSent}` });
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
      
      console.log(`[FSI] ✅ Sent to ${friend.name}, total sent: ${totalSent}`);
      
      // Log to global invite registry
      logInvite(friendId).then(ok => {
        if (ok) console.log(`[FSI] Logged invite to registry: ${friendId}`);
      });
      
      chrome.tabs.remove(tab.id).catch(() => {});
      return true;
    }

    throw new Error(result?.error || 'Unknown send failure');

  } catch (err) {
    console.error(`[FSI] Send failed for ${friend.name}:`, err.message);
    const now = new Date().toISOString();
    campaign.sendRecords[friendId] = {
      status: 'failed',
      messageVariation: variationIndex,
      scheduledAt: campaign.sendRecords[friendId]?.scheduledAt || now,
      sentAt: null,
      error: err.message
    };
    // Silent skip — no error displayed to user (errors logged to console for debugging)
    await setStorage({ campaign });
    chrome.tabs.remove(tab.id).catch(() => {});
    return false;
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Check if campaign is complete
function isCampaignComplete(campaign) {
  const { selectedFriendIds, sendRecords } = campaign;
  return selectedFriendIds.every(id => {
    const rec = sendRecords[id];
    return rec && (rec.status === 'sent' || rec.status === 'failed' || rec.status === 'skipped');
  });
}

// ─── Main Alarm Handler ──────────────────────────────────────────────────────

async function handleSendAlarm() {
  const data = await getStorage(['campaign']);
  let campaign = data.campaign;

  if (!campaign || campaign.status === 'paused' || campaign.status === 'complete' || campaign.status === null) {
    console.log('[FSI] Campaign not active, skipping alarm.');
    return;
  }

  // Daily reset
  const today = todayStr();
  if (campaign.lastSendDate !== today) {
    campaign.sentToday = 0;
    campaign.lastSendDate = today;
  }

  // Check daily limit
  if ((campaign.sentToday || 0) >= MAX_DAILY) {
    console.log('[FSI] Daily limit hit. Rescheduling for tomorrow.');
    const minUntilOpen = minutesUntilWindowOpen();
    scheduleAlarm(minUntilOpen);
    await setStorage({ campaign });
    return;
  }

  // Check time window
  if (!isInWindow()) {
    console.log('[FSI] Outside send window. Rescheduling.');
    const minUntilOpen = minutesUntilWindowOpen();
    scheduleAlarm(minUntilOpen);
    await setStorage({ campaign });
    return;
  }

  // Get next friend
  const friendId = await getNextPendingFriend(campaign);
  if (!friendId) {
    // All done
    campaign.status = 'complete';
    await setStorage({ campaign });
    chrome.action.setBadgeText({ text: '🎉' });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    console.log('[FSI] Campaign complete!');
    return;
  }

  // Mark as in-flight
  if (!campaign.sendRecords[friendId]) {
    campaign.sendRecords[friendId] = {
      status: 'pending',
      messageVariation: null,
      scheduledAt: new Date().toISOString(),
      sentAt: null,
      error: null
    };
  }
  await setStorage({ campaign });

  // Send
  const result = await sendToFriend(friendId, campaign);

  if (result === 'deferred') {
    // Already rescheduled
    return;
  }

  // Check if campaign complete
  if (isCampaignComplete(campaign)) {
    campaign.status = 'complete';
    await setStorage({ campaign });
    chrome.action.setBadgeText({ text: '🎉' });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    console.log('[FSI] Campaign complete!');
    return;
  }

  // Save and schedule next
  await setStorage({ campaign });

  if (isInWindow() && (campaign.sentToday || 0) < MAX_DAILY) {
    scheduleAlarm(randomGapMinutes());
  } else if (!isInWindow()) {
    scheduleAlarm(minutesUntilWindowOpen());
  }
  // If daily limit reached, do nothing — next alarm will fire when reset happens
}

// ─── Chrome Event Listeners ──────────────────────────────────────────────────

// ─── Alarm Recovery ──────────────────────────────────────────────────────────
// Called on every SW startup — reschedules alarm if campaign is active but alarm is missing

async function recoverAlarmIfNeeded() {
  const { campaign } = await getStorage(['campaign']);
  if (!campaign || campaign.status !== 'active') return;

  const alarms = await new Promise(resolve => chrome.alarms.getAll(resolve));
  const hasAlarm = alarms.some(a => a.name === ALARM_NAME);
  if (hasAlarm) return;

  console.log('[FSI] Recovery: active campaign found but no alarm — rescheduling.');
  if (isInWindow() && (campaign.sentToday || 0) < MAX_DAILY) {
    scheduleAlarm(1);
  } else {
    scheduleAlarm(minutesUntilWindowOpen());
  }
}

// Run recovery on every SW wake (install, update, Chrome start, SW restart)
chrome.runtime.onInstalled.addListener(() => recoverAlarmIfNeeded());
chrome.runtime.onStartup.addListener(() => recoverAlarmIfNeeded());
recoverAlarmIfNeeded(); // also runs immediately when SW first loads

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === ALARM_NAME) {
    handleSendAlarm();
  }
});

// ─── Friend Scraping (runs in SW so popup stays open) ────────────────────────

const NAME_SUFFIXES_SW = new Set(['jr', 'jr.', 'sr', 'sr.', 'ii', 'iii', 'iv', 'v', '2nd', '3rd', '4th', 'esq', 'phd', 'md']);

function normalizeAccentsSW(str) {
  return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function stripSuffixesSW(parts) {
  while (parts.length > 1 && NAME_SUFFIXES_SW.has(parts[parts.length - 1])) {
    parts = parts.slice(0, -1);
  }
  return parts;
}

function isHbaMemberSW(memberSet, fullName) {
  if (!fullName || memberSet.size === 0) return false;
  const n = normalizeAccentsSW(fullName.toLowerCase().trim());
  if (memberSet.has(n)) return true;
  
  let fbParts = n.split(/\s+/).filter(Boolean);
  fbParts = stripSuffixesSW(fbParts);
  if (fbParts.length < 2) return false;
  
  const fbFirst = fbParts[0];
  const fbLast = fbParts[fbParts.length - 1];
  
  // First + last match
  if (memberSet.has(`${fbFirst} ${fbLast}`)) return true;
  
  // Check against each member with flexible matching
  for (const m of memberSet) {
    // Handle joint accounts like "Chris and Susan Beesley"
    const jointNames = m.includes(' and ') ? m.split(' and ') : [m];
    
    for (const jointName of jointNames) {
      let mParts = jointName.trim().split(/\s+/).filter(Boolean);
      mParts = stripSuffixesSW(mParts);
      if (mParts.length < 1) continue;
      
      const origParts = stripSuffixesSW(m.split(/\s+/).filter(Boolean));
      const mFirst = mParts[0];
      const mLast = mParts.length >= 2 ? mParts[mParts.length - 1] : origParts[origParts.length - 1];
      
      // Check if first names match (exact, prefix, or common root)
      let commonPrefix = 0;
      for (let i = 0; i < Math.min(mFirst.length, fbFirst.length); i++) {
        if (mFirst[i] === fbFirst[i]) commonPrefix++;
        else break;
      }
      
      const firstNameMatch = 
        mFirst === fbFirst || 
        (mFirst.length >= 3 && fbFirst.startsWith(mFirst)) ||
        (fbFirst.length >= 3 && mFirst.startsWith(fbFirst)) ||
        (commonPrefix >= 4);
      
      if (!firstNameMatch) continue;
      
      if (mLast === fbLast) return true;
      if (mParts.includes(fbLast)) return true;
      if (fbParts.includes(mLast)) return true;
    }
  }
  return false;
}

async function handleScrapeFriends() {
  try {
    await setStorage({ scrapeProgress: 0, scrapeStatus: 'running', scrapeError: null });
    
    // Show loading badge
    chrome.action.setBadgeText({ text: '...' });
    chrome.action.setBadgeBackgroundColor({ color: '#2196F3' });

    // Find existing friends tab or open a new one
    const existingTabs = await new Promise(resolve =>
      chrome.tabs.query({ url: '*://*.facebook.com/friends*' }, resolve)
    );
    let tabId, createdTab = false;
    if (existingTabs.length > 0) {
      tabId = existingTabs[0].id;
    } else {
      const tab = await new Promise(resolve =>
        chrome.tabs.create({ url: 'https://www.facebook.com/friends/list', active: true }, resolve)
      );
      tabId = tab.id;
      createdTab = true;
      await waitForTabLoad(tabId, 20000);
      await sleep(2000);
    }

    // Scroll loop — collect friends into a Map as we scroll (Facebook virtualizes the list)
    const collectedFriends = new Map(); // id -> friend object
    let stableScrollRounds = 0;
    let lastScrollTop = -1;
    
    for (let i = 0; i < 120; i++) {
      // Extract friends currently in DOM and scroll
      const res = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          // Find scroll container
          const el = Array.from(document.querySelectorAll('div')).find(e => {
            const s = getComputedStyle(e);
            return ['auto','scroll'].includes(s.overflowY) && e.scrollHeight > e.clientHeight + 200;
          });
          
          // Extract all friend links currently in DOM
          const friends = Array.from(
            document.querySelectorAll('[aria-label="All friends"] a[href*="facebook.com"]')
          ).map(l => {
            const name = (l.textContent || '').trim().replace(/\d+\s+mutual.*$/i, '').trim();
            const href = l.href || '';
            const userId = href.includes('profile.php')
              ? href.match(/id=(\d+)/)?.[1]
              : href.split('facebook.com/')[1]?.split('?')[0]?.split('/')[0];
            const svgImg = l.querySelector('svg image');
            const profilePhotoUrl = svgImg?.href?.baseVal || svgImg?.getAttribute('xlink:href') || '';
            return { id: userId, name, firstName: name.split(' ')[0] || '', profilePhotoUrl, hbaMember: false };
          }).filter(f => f.name && f.id && f.name.length > 1);
          
          // Scroll down
          const scrollTop = el ? el.scrollTop : 0;
          const scrollHeight = el ? el.scrollHeight : 0;
          const clientHeight = el ? el.clientHeight : 0;
          if (el) el.scrollTop += 800;
          
          return { friends, scrollTop, scrollHeight, clientHeight };
        }
      });
      
      const { friends, scrollTop, scrollHeight, clientHeight } = res[0]?.result || { friends: [], scrollTop: 0, scrollHeight: 0, clientHeight: 0 };
      
      // Add new friends to our collection
      for (const f of friends) {
        if (!collectedFriends.has(f.id)) {
          collectedFriends.set(f.id, f);
        }
      }
      
      const totalCollected = collectedFriends.size;
      await setStorage({ scrapeProgress: totalCollected });
      chrome.action.setBadgeText({ text: totalCollected > 0 ? String(totalCollected) : '...' });
      
      // Check if we've reached the bottom (scroll position stopped changing)
      const atBottom = scrollTop + clientHeight >= scrollHeight - 50;
      if (scrollTop === lastScrollTop) {
        stableScrollRounds++;
      } else {
        stableScrollRounds = 0;
        lastScrollTop = scrollTop;
      }
      
      // Stop if we've been at the bottom for 5 rounds or scroll hasn't moved for 8 rounds
      if ((atBottom && stableScrollRounds >= 5) || stableScrollRounds >= 8) {
        console.log(`[FSI] Scroll complete: ${totalCollected} friends collected`);
        break;
      }
      
      await sleep(800);
    }

    const rawFriends = Array.from(collectedFriends.values());
    if (rawFriends.length === 0) throw new Error("No friends found — make sure you're logged into Facebook");

    // Fetch HBA members and mark
    const hbaResult = await fetchHbaMembers();
    const memberSet = new Set(hbaResult.members || []);
    const friendsWithHba = rawFriends.map(f => ({ ...f, hbaMember: isHbaMemberSW(memberSet, f.name) }));

    // Check global invite registry
    const friendIds = friendsWithHba.map(f => f.id).filter(Boolean);
    const inviteRegistry = await bulkCheckInvites(friendIds);
    const friendsWithInvites = friendsWithHba.map(f => ({
      ...f,
      invitedDate: inviteRegistry[f.id] || null
    }));

    await setStorage({ friends: friendsWithInvites, hbaMembers: [...memberSet], scrapeStatus: 'done' });
    console.log(`[FSI] Scrape done: ${friendsWithInvites.length} friends, ${Object.keys(inviteRegistry).length} previously invited`);
    
    // Update badge to show success
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    
    // Inject overlay into the page instead of closing
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (friendCount) => {
        // Remove any existing overlay
        const existing = document.getElementById('fsi-overlay');
        if (existing) existing.remove();
        
        // Create overlay
        const overlay = document.createElement('div');
        overlay.id = 'fsi-overlay';
        overlay.innerHTML = `
          <div style="
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 24px 32px;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 999999;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 320px;
            animation: slideIn 0.3s ease-out;
          ">
            <style>
              @keyframes slideIn {
                from { transform: translateX(100px); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
              }
            </style>
            <div style="font-size: 32px; margin-bottom: 8px;">🎉</div>
            <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">
              ${friendCount} friends loaded!
            </div>
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 16px;">
              Click the <strong>Fast Start Inviter</strong> extension icon to select who to invite.
            </div>
            <button id="fsi-overlay-close" style="
              background: rgba(255,255,255,0.2);
              border: none;
              color: white;
              padding: 8px 16px;
              border-radius: 8px;
              cursor: pointer;
              font-size: 14px;
            ">Got it!</button>
          </div>
        `;
        document.body.appendChild(overlay);
        
        // Close button handler
        document.getElementById('fsi-overlay-close').onclick = () => overlay.remove();
        
        // Auto-dismiss after 30 seconds
        setTimeout(() => overlay.remove(), 30000);
      },
      args: [friendsWithInvites.length]
    });
    
    return { success: true };
  } catch (err) {
    console.error('[FSI] Scrape failed:', err.message);
    await setStorage({ scrapeStatus: 'error', scrapeError: err.message });
    
    // Show error on badge
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#f44336' });
    
    return { success: false, error: err.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_SCRAPE') {
    handleScrapeFriends().then(sendResponse);
    return true;
  }
  if (message.type === 'START_CAMPAIGN') {
    handleStartCampaign(message.payload).then(sendResponse);
    return true;
  }
  if (message.type === 'PAUSE_CAMPAIGN') {
    handlePauseCampaign().then(sendResponse);
    return true;
  }
  if (message.type === 'RESUME_CAMPAIGN') {
    handleResumeCampaign().then(sendResponse);
    return true;
  }
  if (message.type === 'CANCEL_CAMPAIGN') {
    handleCancelCampaign().then(sendResponse);
    return true;
  }
  if (message.type === 'GET_STATUS') {
    getStatus().then(sendResponse);
    return true;
  }
  if (message.type === 'FETCH_HBA_MEMBERS') {
    fetchHbaMembers().then(sendResponse);
    return true;
  }
  if (message.type === 'CLEAR_BADGE') {
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ success: true });
    return true;
  }
  if (message.type === 'AUTHENTICATE') {
    authenticateDevice(message.email).then(result => {
      sendResponse(result);
    });
    return true;
  }
});

async function handleStartCampaign({ selectedFriendIds }) {
  const today = todayStr();

  // Build send records
  const sendRecords = {};
  for (const id of selectedFriendIds) {
    sendRecords[id] = {
      status: 'pending',
      messageVariation: null,
      scheduledAt: null,
      sentAt: null,
      error: null
    };
  }

  const campaign = {
    status: 'active',
    selectedFriendIds,
    sendRecords,
    startedAt: new Date().toISOString(),
    sentToday: 0,
    lastSendDate: today,
    lastVariationIndex: null
  };

  await setStorage({ campaign });

  // Schedule first send — within 1 min if in window, else wait for window
  if (isInWindow()) {
    scheduleAlarm(1);
  } else {
    scheduleAlarm(minutesUntilWindowOpen());
  }

  return { success: true };
}

async function handlePauseCampaign() {
  const { campaign } = await getStorage(['campaign']);
  if (campaign) {
    campaign.status = 'paused';
    await setStorage({ campaign });
    chrome.alarms.clear(ALARM_NAME);
  }
  return { success: true };
}

async function handleResumeCampaign() {
  const { campaign } = await getStorage(['campaign']);
  if (campaign) {
    campaign.status = 'active';
    await setStorage({ campaign });
    if (isInWindow() && (campaign.sentToday || 0) < MAX_DAILY) {
      scheduleAlarm(1);
    } else {
      scheduleAlarm(minutesUntilWindowOpen());
    }
  }
  return { success: true };
}

async function handleCancelCampaign() {
  await setStorage({ campaign: null });
  chrome.alarms.clear(ALARM_NAME);
  return { success: true };
}

async function getStatus() {
  const data = await getStorage(['campaign', 'friends']);
  const campaign = data.campaign;
  if (!campaign) return { campaign: null };

  const total = campaign.selectedFriendIds?.length || 0;
  const sent = Object.values(campaign.sendRecords || {}).filter(r => r.status === 'sent').length;
  const failed = Object.values(campaign.sendRecords || {}).filter(r => r.status === 'failed').length;
  const skipped = Object.values(campaign.sendRecords || {}).filter(r => r.status === 'skipped').length;
  
  // DEBUG: Log what we're returning
  console.log(`[FSI] getStatus: total=${total}, sent=${sent}, failed=${failed}, skipped=${skipped}, status=${campaign.status}`);

  // Get next alarm
  let nextAlarmMinutes = null;
  const alarms = await new Promise(resolve => chrome.alarms.getAll(resolve));
  const alarm = alarms.find(a => a.name === ALARM_NAME);
  if (alarm) {
    nextAlarmMinutes = Math.max(0, Math.round((alarm.scheduledTime - Date.now()) / 60000));
  }

  // Estimate completion date
  const remaining = total - sent - failed;
  const avgPerDay = 8; // conservative estimate
  const daysRemaining = remaining > 0 ? Math.ceil(remaining / avgPerDay) : 0;
  const estComplete = new Date();
  estComplete.setDate(estComplete.getDate() + daysRemaining);
  const estCompleteStr = estComplete.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  // Days elapsed
  const startedAt = campaign.startedAt ? new Date(campaign.startedAt) : new Date();
  const daysElapsed = Math.max(1, Math.ceil((Date.now() - startedAt.getTime()) / 86400000));

  return {
    campaign: {
      ...campaign,
      sent,
      total,
      failed,
      skipped,
      nextAlarmMinutes,
      estComplete: estCompleteStr,
      daysElapsed
    }
  };
}

// Call HBA MCP API — handles SSE response format
async function callHbaMcp(toolName, args = {}) {
  const res = await fetch('https://thehba.app/api/mcp', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer hba_f894f9b4071a7934e6e1c1e68297a9935731e70b8f20729741ffe8bfa8c35c02',
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream'  // API requires BOTH
    },
    body: JSON.stringify({
      jsonrpc: '2.0', id: 1, method: 'tools/call',
      params: { name: toolName, arguments: args }
    })
  });
  // Response is SSE format: "event: message\ndata: {...}\n\n"
  const text = await res.text();
  const dataLine = text.split('\n').find(l => l.startsWith('data: '));
  if (!dataLine) throw new Error('No data line in SSE response');
  const envelope = JSON.parse(dataLine.substring(6));
  const textContent = envelope?.result?.content?.find?.(c => c.type === 'text')?.text;
  if (!textContent) throw new Error('No text content in MCP response');
  return JSON.parse(textContent);
}

async function fetchHbaMembers() {
  try {
    // get_active_customers returns ALL HBA customers (1463+), paginated
    // Fetch all pages with limit=500 (3 requests max)
    const allMembers = [];
    let offset = 0;
    const limit = 500;

    while (true) {
      const data = await callHbaMcp('admin_active_customers', { limit, offset });
      const customers = data.customers || [];
      const total = parseInt(data.totalCount || '0');

      for (const c of customers) {
        const name = `${c.firstName || ''} ${c.lastName || ''}`.trim().toLowerCase();
        if (name) allMembers.push(name);
      }

      offset += customers.length;
      console.log(`[FSI] HBA members loaded: ${allMembers.length} / ${total}`);

      if (customers.length === 0 || allMembers.length >= total) break;
    }

    console.log('[FSI] Total HBA members:', allMembers.length, '| Sample:', allMembers.slice(0, 5));
    await setStorage({ hbaMembers: allMembers });
    return { success: true, members: allMembers };
  } catch (err) {
    console.error('[FSI] Failed to fetch HBA members:', err);
    return { success: false, error: err.message, members: [] };
  }
}
